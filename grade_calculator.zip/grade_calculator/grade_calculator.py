# grade_calculator.py

from utils import (
    calculate_average,
    assign_letter_grade,
    validate_grade,
    find_class_extremes,
)


def main():

    students = {}

    print("📘 Grade Calculator")
    print("Enter student names (Press Enter to finish)\n")

    # Input student names
    while True:

        name = input("Enter student name: ").strip()

        if name == "":
            break

        grades = []

        print(f"Enter 3 grades for {name}:")

        # Collect 3 grades
        for i in range(1, 4):

            while True:
                score = input(f"  Grade {i}: ")

                try:
                    valid_score = validate_grade(score)
                    grades.append(valid_score)
                    break

                except ValueError as e:
                    print("  ❌", e)

        students[name] = grades
        print()

    # Check if no students entered
    if not students:
        print("\nNo data entered. Exiting program.")
        return

    # Generate Report
    print("\n📊 Final Report\n")

    print(f"{'Name':<15}{'Average':<10}{'Letter Grade'}")
    print("-" * 35)

    for name, grades in students.items():

        avg = calculate_average(grades)
        letter = assign_letter_grade(avg)

        print(f"{name:<15}{avg:<10.2f}{letter}")

    # Find highest and lowest
    highest_name, highest_avg, lowest_name, lowest_avg = find_class_extremes(
        students
    )

    print("\n📈 Class Extremes")
    print(f"Highest average: {highest_name} ({highest_avg:.2f})")
    print(f"Lowest average: {lowest_name} ({lowest_avg:.2f})")


# Run program
if __name__ == "__main__":
    main()
