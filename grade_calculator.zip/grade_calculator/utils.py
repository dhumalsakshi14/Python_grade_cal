
# utils.py

def calculate_average(grades):
    """
    Returns the average of a list of grades.
    """
    return sum(grades) / len(grades)


def assign_letter_grade(avg):
    """
    Returns letter grade based on average.
    """
    if avg >= 90:
        return "A"
    elif avg >= 80:
        return "B"
    elif avg >= 70:
        return "C"
    elif avg >= 60:
        return "D"
    else:
        return "F"


def validate_grade(score):
    """
    Validates input score (0–100).
    Returns float if valid, otherwise raises ValueError.
    """
    try:
        score = float(score)

        if 0 <= score <= 100:
            return score
        else:
            raise ValueError("Score must be between 0 and 100.")

    except ValueError:
        raise ValueError("Invalid input. Enter a number between 0 and 100.")


def find_class_extremes(students):
    """
    Finds students with highest and lowest averages.
    Returns (highest_name, highest_avg, lowest_name, lowest_avg)
    """

    averages = {}

    for name, grades in students.items():
        avg = calculate_average(grades)
        averages[name] = avg

    highest_name = max(averages, key=averages.get)
    lowest_name = min(averages, key=averages.get)

    return (
        highest_name,
        averages[highest_name],
        lowest_name,
        averages[lowest_name],
    )
